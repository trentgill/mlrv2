Installing [xgroove~]


Copy 'xsample.mxo' to:
Max5/Cycling '74/msp-externals/

Copy 'xsample-objectmappings.txt' to:
Max5/Cycling '74/init/

Copy 'xsample.help' to:
Max5/Cycling '74/msp-help/


Restart Max5